'use strict';
console.log('Loading function');

exports.handler = (event, context, callback) => {
    callback(null, {
      "isBase64Encoded": false,
      "statusCode": 200,
      "body": JSON.stringify({ data: { number: Math.random() } })
    });
};
